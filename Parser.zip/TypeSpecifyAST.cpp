#include "TypeSpecifyAST.h"


/*

VarDecAST::VarDecAST(Type type, IdListAST* idList)
{
	this->type = type; this->idList = idList;
}

VarDecAST::VarDecAST(Type type, Type toType, IdListAST* idList):VarDecAST(type,idList)
{
	this->toType = toType;
}

*/