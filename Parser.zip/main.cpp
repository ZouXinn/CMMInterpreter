#include <iostream>
#include "unitTest.h"



int main()
{
	//testLexer();
	testParser();
	//testParser2();
	return 0;
}