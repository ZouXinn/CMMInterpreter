#include "OperatorAST.h"


OperatorAST::OperatorAST(Op op)
{
	this->op = op;
}