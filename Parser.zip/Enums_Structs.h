#pragma once
namespace zx {
	enum class Type {
		INT,
		REAL,
		CHAR,
		VOID,
		STRUCT,
		POINTER,
		STRING
	};
}

