#include "AST.h"


AST::~AST()
{
	
}

void AST::setRow(int row)
{
	this->row = row;
}