#pragma once



void testLexer();
void testParser();
void testParser2();