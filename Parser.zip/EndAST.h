#pragma once
#include "AST.h"
#include <string>
class EndAST :
	public AST
{
public:
	string tag = "$";
};

