#pragma once
class Struct
{

};

