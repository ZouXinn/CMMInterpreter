#include "PointerAST.h"


PointerAST::PointerAST(int starNum)
{
	this->starNum = starNum;
}
void PointerAST::addStarNum()
{
	this->starNum++;
}